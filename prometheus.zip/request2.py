import http.server, random
from prometheus_client import start_http_server, Counter

REQUESTS = Counter('hello_worlds_total', 'Hello Worlds requested')
EXCEPTIONS = Counter('hello_world_exceptions_total','Exceptions serving Hello World')

class MyHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        value = random.random()
        REQUESTS.inc()
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"Hello World")
        with EXCEPTIONS.count_exceptions():
          if value < 0.5:
            raise Exception
        self.wfile.write(b"\nNo exception")

if __name__ == "__main__":
    start_http_server(8000)
    server = http.server.HTTPServer(('0.0.0.0', 8001), MyHandler)
    server.serve_forever()